#include <SFML/Graphics.hpp>
#include <optional>
#include <iostream>
#include <string>
#include <cstdint>
#include <deque>

#include <req/clientcore/ClientCore.h>
#include <req/shared/MessageTypes.h>
#include "VizWorldState.h"

int main()
{
    using namespace req::clientcore;

    // ---------------------------------------------------------------------
    // 1) Setup client config + session
    // ---------------------------------------------------------------------
    ClientConfig config{};
    ClientSession session{};

    // TODO: Replace with your actual test credentials / config
    const std::string username = "testuser";
    const std::string password = "testpass";

    std::cout << "[REQ_VizTestClient] Logging in as '" << username << "'...\n";

    auto loginResp = login(
        config,
        username,
        password,
        req::shared::protocol::LoginMode::Login,
        session
    );

    if (loginResp.result != LoginResult::Success)
    {
        std::cerr << "[REQ_VizTestClient] Login failed: "
            << loginResp.errorMessage << "\n";
        return 1;
    }

    std::cout << "[REQ_VizTestClient] Login OK. Worlds available: "
        << loginResp.availableWorlds.size() << "\n";

    // ---------------------------------------------------------------------
    // 2) Character list / create / select
    // ---------------------------------------------------------------------
    std::cout << "[REQ_VizTestClient] Requesting character list...\n";
    auto charListResp = getCharacterList(session);

    if (charListResp.result != CharacterListResult::Success)
    {
        std::cerr << "[REQ_VizTestClient] Character list failed: "
            << charListResp.errorMessage << "\n";
        return 1;
    }

    std::uint64_t chosenCharacterId = 0;

    if (!charListResp.characters.empty())
    {
        const auto& ch = charListResp.characters.front();
        chosenCharacterId = ch.characterId;

        std::cout << "[REQ_VizTestClient] Using existing character: "
            << ch.name << " (id=" << ch.characterId << ")\n";
    }
    else
    {
        std::cout << "[REQ_VizTestClient] No characters found, creating one...\n";

        const std::string newName = "VizTester";
        const std::string race = "Human";
        const std::string characterClass = "Warrior";

        auto createResp = createCharacter(session, newName, race, characterClass);
        if (createResp.result != CharacterListResult::Success)
        {
            std::cerr << "[REQ_VizTestClient] Character creation failed: "
                << createResp.errorMessage << "\n";
            return 1;
        }

        chosenCharacterId = createResp.newCharacter.characterId;

        std::cout << "[REQ_VizTestClient] Created character: "
            << newName << " (id=" << chosenCharacterId << ")\n";
    }

    // ---------------------------------------------------------------------
    // 3) Enter world + connect to zone
    // ---------------------------------------------------------------------
    std::cout << "[REQ_VizTestClient] Entering world...\n";
    auto enterResp = enterWorld(session, chosenCharacterId);

    if (enterResp.result != EnterWorldResult::Success)
    {
        std::cerr << "[REQ_VizTestClient] Enter world failed: "
            << enterResp.errorMessage << "\n";
        return 1;
    }

    std::cout << "[REQ_VizTestClient] Connecting to zone...\n";
    auto zoneResp = connectToZone(session);

    if (zoneResp.result != ZoneAuthResult::Success)
    {
        std::cerr << "[REQ_VizTestClient] Zone connect failed: "
            << zoneResp.errorMessage << "\n";
        return 1;
    }

    std::cout << "[REQ_VizTestClient] Zone connection established.\n";

    // Client-side viz state
    VizWorldState worldState;
    worldState.setLocalCharacterId(chosenCharacterId);

    // ---------------------------------------------------------------------
    // 4) SFML window + coordinate transform
    // ---------------------------------------------------------------------
    sf::RenderWindow window(
        sf::VideoMode({ 1280u, 720u }),
        "REQ VizTestClient",
        sf::Style::Titlebar | sf::Style::Close
    );
    window.setFramerateLimit(60);

    // World-to-screen scale (DO NOT CHANGE)
    const float baseScale = 0.000001f;

    std::uint32_t movementSeq = 0;

    // Trail for local player (max 200 points)
    std::deque<sf::Vector2f> playerTrail;

    // ---------------------------------------------------------------------
    // 5) Main loop: input, zone messages, render
    // ---------------------------------------------------------------------
    while (window.isOpen())
    {
        // --- SFML events ---
        while (const std::optional<sf::Event> event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
            {
                window.close();
            }

            if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>())
            {
                if (keyPressed->scancode == sf::Keyboard::Scan::Escape)
                {
                    window.close();
                }
            }
        }

        // --- Keyboard -> movement intent (WASD + Space) ---
        float inputX = 0.0f;
        float inputY = 0.0f;
        bool  jump = false;

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::W))
            inputY += 1.0f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::S))
            inputY -= 1.0f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::A))
            inputX -= 1.0f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::D))
            inputX += 1.0f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Scan::Space))
            jump = true;

        if (inputX != 0.0f || inputY != 0.0f || jump)
        {
            const float yaw = 0.0f; // TODO: hook up camera/heading later

            const bool ok = sendMovementIntent(
                session,
                inputX,
                inputY,
                yaw,
                jump,
                ++movementSeq
            );

            if (!ok)
            {
                std::cerr << "[REQ_VizTestClient] sendMovementIntent failed\n";
            }
        }

        // --- Pump zone messages into VizWorldState ---
        {
            ZoneMessage msg;
            using MT = req::shared::MessageType;

            static int unhandledLogBudget = 20;

            while (tryReceiveZoneMessage(session, msg))
            {
                switch (msg.type)
                {
                case MT::PlayerStateSnapshot:
                {
                    req::shared::protocol::PlayerStateSnapshotData snapshot;
                    if (parsePlayerStateSnapshot(msg.payload, snapshot))
                    {
                        worldState.applyPlayerStateSnapshot(snapshot);
                    }
                    break;
                }

                case MT::EntitySpawn:
                {
                    req::shared::protocol::EntitySpawnData spawn;
                    if (parseEntitySpawn(msg.payload, spawn))
                    {
                        worldState.applyEntitySpawn(spawn);
                    }
                    break;
                }

                case MT::EntityUpdate:
                {
                    req::shared::protocol::EntityUpdateData update;
                    if (parseEntityUpdate(msg.payload, update))
                    {
                        worldState.applyEntityUpdate(update);
                    }
                    break;
                }

                case MT::EntityDespawn:
                {
                    req::shared::protocol::EntityDespawnData despawn;
                    if (parseEntityDespawn(msg.payload, despawn))
                    {
                        worldState.applyEntityDespawn(despawn);
                    }
                    break;
                }

                default:
                    if (unhandledLogBudget > 0)
                    {
                        std::cout << "[REQ_VizTestClient] Unhandled zone msg type = "
                            << static_cast<int>(msg.type) << "\n";
                        --unhandledLogBudget;
                    }
                    break;
                }
            }
        }

        // --- Render world state ---
        window.clear(sf::Color(30, 30, 40));

        // Camera position (centered on local player)
        sf::Vector2f cameraWorld{ 0.f, 0.f };
        bool foundLocalPlayer = false;
        for (const auto& [id, entity] : worldState.getEntities())
        {
            if (id == chosenCharacterId)
            {
                cameraWorld.x = entity.posX;
                cameraWorld.y = entity.posY;
                foundLocalPlayer = true;
                break;
            }
        }

        // Update player trail (world space)
        if (foundLocalPlayer)
        {
            playerTrail.push_back(cameraWorld);
            if (playerTrail.size() > 200)
            {
                playerTrail.pop_front();
            }
        }

        // Camera-relative world-to-screen transform
        const float windowWidth = 1280.f;
        const float windowHeight = 720.f;
        const float pixelsPerWorldUnit = baseScale;

        auto worldToScreen = [&](float wx, float wy) -> sf::Vector2f {
            const float screenX = (windowWidth / 2.f) + (wx - cameraWorld.x) * pixelsPerWorldUnit;
            const float screenY = (windowHeight / 2.f) - (wy - cameraWorld.y) * pixelsPerWorldUnit;
            return sf::Vector2f{ screenX, screenY };
        };

        // Draw player trail
        if (playerTrail.size() > 1)
        {
            sf::VertexArray trail(sf::PrimitiveType::LineStrip, playerTrail.size());
            for (std::size_t i = 0; i < playerTrail.size(); ++i)
            {
                sf::Vector2f screenPos = worldToScreen(playerTrail[i].x, playerTrail[i].y);
                trail[i].position = screenPos;
                
                // Fade trail from transparent (oldest) to semi-opaque (newest)
                float alpha = static_cast<float>(i) / static_cast<float>(playerTrail.size() - 1);
                std::uint8_t alphaValue = static_cast<std::uint8_t>(alpha * 150);
                trail[i].color = sf::Color(0, 255, 0, alphaValue);
            }
            window.draw(trail);
        }

        // Draw entities from worldState
        for (const auto& [id, entity] : worldState.getEntities())
        {
            const sf::Vector2f screenPos = worldToScreen(entity.posX, entity.posY);

            sf::CircleShape shape;
            shape.setRadius(entity.isLocalPlayer ? 8.f : 6.f);
            shape.setOrigin({ shape.getRadius(), shape.getRadius() });

            if (entity.isNpc)
                shape.setFillColor(sf::Color::Red);
            else if (entity.isLocalPlayer)
                shape.setFillColor(sf::Color::Green);
            else
                shape.setFillColor(sf::Color::Blue);

            shape.setPosition(screenPos);
            window.draw(shape);
        }

        window.display();
    }

    // ---------------------------------------------------------------------
    // 6) Clean shutdown
    // ---------------------------------------------------------------------
    disconnectFromZone(session);

    std::cout << "[REQ_VizTestClient] Shutdown.\n";
    return 0;
}
