#include "../include/req/testclient/BotClient.h"

#include "../../REQ_Shared/include/req/shared/ProtocolSchemas.h"
#include "../../REQ_Shared/include/req/shared/Logger.h"

#include <string>
#include <random>
#include <chrono>

namespace req::testclient {

// Combat-related methods will go here when combat is implemented
// Currently no combat functionality in BotClient

} // namespace req::testclient
